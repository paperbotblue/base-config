return {
  'akinsho/toggleterm.nvim',
  version = "*",
  config = function()
    require("toggleterm").setup({
      direction = 'horizontal',
      size = function(term)
        if term.direction == "horizontal" then
          return 15
        elseif term.direction == "vertical" then
          return vim.o.columns * 0.4
        end
        return 20
      end,

      -- FIXED: Correct escaping for <C-\>
      open_mapping = [[<C-\>]],

      hide_numbers = true,
      shade_filetypes = {},
      autochdir = false,
      highlights = {
        Normal = { guibg = "NONE" },
        NormalFloat = { link = 'Normal' },
        FloatBorder = { guifg = "#FFFFFF", guibg = "NONE" },
      },
      shade_terminals = true,
      shading_factor = -30,
      start_in_insert = true,
      insert_mappings = true,
      terminal_mappings = true,
      persist_size = true,
      persist_mode = true,
      close_on_exit = true,
      shell = vim.o.shell,
      auto_scroll = true,
      float_opts = {
        border = 'curved',
        width = function() return math.floor(vim.o.columns * 0.8) end,
        height = function() return math.floor(vim.o.lines * 0.8) end,
        winblend = 3,
      },
      winbar = {
        enabled = false,
        name_formatter = function(term) return term.name end
      },
    })
  end
}
