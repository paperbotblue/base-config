#!/bin/bash

sudo mongod --dbpath ./.mongodb/mongod_database_files --port 27017

