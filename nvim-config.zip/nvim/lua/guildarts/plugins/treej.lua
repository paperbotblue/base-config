return {
  'Wansmer/treesj',
  dependencies = { 'nvim-treesitter/nvim-treesitter' },
  keys = {
    {
      "<leader>nn",
      function() require("treesj").toggle() end,
      desc = "Toggle split/join",
    },
    {
      "<leader>n", -- optional: split
      function() require("treesj").split() end,
      desc = "Split block"
    },
    {
      "<leader>j", -- optional: join
      function() require("treesj").join() end,
      desc = "Join block"
    },
  },
  config = function()
    require("treesj").setup({
      use_default_keymaps = false,
    })
  end,
}

