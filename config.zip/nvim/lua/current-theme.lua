vim.cmd("colorscheme catppuccin")

